#!/bin/bash

LOG_DIR="../myapp/logs"

echo "Verificando os logs no diretorio $LOG_DIR" 
